#ifndef SERIALCONTROLLER_H
#define SERIALCONTROLLER_H
class SerialController
{

public:
    static void init();

private:
    const int DIGITAL_PINS = 14;
    const int ANALOG_PINS = 6;
    const byte BOF = 0xFF;
    const byte SIZE = 0;
    const int OUT_MESSAGE_LEN = 18;
    const byte PIN_MODE = 0xF0;
    const byte DIGITAL_WRITE = 0xF1;
    const byte ANALOG_WRITE = 0xF2;
    const byte DIGITAL_READ = 0xF3;
    const byte ANALOG_READ = 0xF4;
    const byte ACK = 0xFE;
    const byte NACK = 0xFD;
    int counter = 0;
    byte pin = 0, value = 0;

    byte Crc8(const byte *data, int len);
    byte mCRC(const byte *data, int len);
    byte mlow7(int i);
    byte mhigh7(int i);
    void sendMsg(byte command, byte _msb, byte _lsb);
    void readCommands(void);
};
#endif